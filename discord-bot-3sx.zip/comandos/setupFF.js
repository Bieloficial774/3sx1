const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const { saveFilas } = require('../utils/database');
const path = require('path');

const LOGO_PATH = path.join(__dirname, '../logo.png');

const VALORES_PRESET = [100.00, 50.00, 30.00, 20.00, 10.00, 5.00, 3.00, 2.00, 1.00, 0.75, 0.50];

const CATEGORIAS = {
  '📱 MOBILE': ['🎮・1x1-mob', '🎮・2x2-mob', '🎮・3x3-mob', '🎮・4x4-mob'],
  '🖥️ MISTO': ['🎮・2x2-misto', '🎮・3x3-misto', '🎮・4x4-misto'],
  '💻 EMULADOR': ['🎮・1x1-emu', '🎮・2x2-emu', '🎮・3x3-emu', '🎮・4x4-emu'],
  '🥊 FULL SOCO': ['📜・regras-full-soco', '🥊・1x1-full-soco', '🥊・2x2-full-soco', '🥊・3x3-full-soco', '🥊・4x4-full-soco']
};

const REGRAS_FULL_SOCO = `**REGRAS FULL SOCO**

**PERSONAGENS VÁLIDOS**
✅ PERMITIDO ALOK
✅ PERMITIDO KELLY
✅ PERMITIDO MAXIM
✅ PERMITIDO MOCO
✅ PERMITIDO KLA
✅ PERMITIDO LEON

⚠️ PERSONAGEM PASSIVO ERRADO, REFAZER 1X0. (COMUNICAR O MEDIADOR ATÉ O 3 ROUND).
⚠️ PERSONAGEM ATIVO DAR 1 ROUND PARA CADA ROUND QUE USAR.
⚠️ PERSONAGEM PASSIVO: PASSAR DO 3 ROUND E NÃO AVISAR É WO!

**PETS INVALIDOS**
❌ SEM ETZINHO
❌ SEM DRAKINHO
❌ SEM ROBÔZINHO
❌ SEM MANDRAKO
⚠️ PET ERRADO REFAZER 1X0 (COMUNICAR O MEDIADOR ATÉ O 3 ROUND).
❌ SE PASSAR DO 3 ROUND E NÃO AVISAR É WO!

**REGRAS COMPLEMENTARES**
🚫 NÃO É VÁLIDO NENHUM TIPO DE ARMA
🚫 SE USAR ARMA E ACERTAR, ENTREGAR 3 ROUNDS
🚫 PROIBIDO GRANADA (EXCETO GEL)
🚫 SE USAR GRANADA E INTERFERIR, ENTREGAR 1 ROUND OU WO`;

function buildEmbedValor(modeName, valor, geloNormal, geloInfinito) {
  const geloNormalStr = geloNormal ? `<@${geloNormal}>` : 'Nenhum jogador na fila';
  const geloInfinitoStr = geloInfinito ? `<@${geloInfinito}>` : 'Nenhum jogador na fila';

  return new EmbedBuilder()
    .setTitle(`${modeName} | ORG 3SX 40c`)
    .addFields(
      { name: '🎮 Modo:', value: modeName, inline: false },
      { name: '💰 Valor:', value: `R$ ${valor.toFixed(2)}`, inline: false },
      {
        name: '👤 Jogadores:',
        value: `🧊 Gelo Normal: ${geloNormalStr}\n❄️ Gelo Infinito: ${geloInfinitoStr}`,
        inline: false
      }
    )
    .setColor('#8B0000')
    .setThumbnail('attachment://logo.png');
}

function getLogo() {
  return new AttachmentBuilder(LOGO_PATH, { name: 'logo.png' });
}

async function enviarEmbedsValores(canal, modeName) {
  const filas = {};

  for (const valor of VALORES_PRESET) {
    const embed = buildEmbedValor(modeName, valor, null, null);
    const logo = getLogo();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`fila_gelon_PLACEHOLDER`)
        .setLabel('🎮 Gelo Normal')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`fila_geloi_PLACEHOLDER`)
        .setLabel('🎮 Gelo Infinito')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`sair_msg_PLACEHOLDER`)
        .setLabel('❌ Sair da fila')
        .setStyle(ButtonStyle.Danger)
    );

    const msg = await canal.send({ embeds: [embed], files: [logo], components: [row] });

    const rowFinal = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`fila_gelon_${msg.id}`)
        .setLabel('🎮 Gelo Normal')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`fila_geloi_${msg.id}`)
        .setLabel('🎮 Gelo Infinito')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`sair_msg_${msg.id}`)
        .setLabel('❌ Sair da fila')
        .setStyle(ButtonStyle.Danger)
    );

    await msg.edit({ embeds: [embed], components: [rowFinal] });

    filas[msg.id] = {
      valor,
      modo: modeName,
      canalId: canal.id,
      geloNormal: null,
      geloInfinito: null,
      messageId: msg.id
    };
  }

  return filas;
}

module.exports = {
  buildEmbedValor,
  getLogo,
  data: new SlashCommandBuilder()
    .setName('setup-ff')
    .setDescription('Configura todos os canais de apostas Free Fire')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const guild = interaction.guild;

    try {
      await interaction.editReply({ content: '⏳ Deletando categorias antigas...' });

      const nomesCategoria = Object.keys(CATEGORIAS);
      const categoriasExistentes = guild.channels.cache.filter(
        c => c.type === ChannelType.GuildCategory &&
          nomesCategoria.some(n => c.name.includes(n.replace(/[^\w\s]/gu, '').trim().split(' ').pop()))
      );

      for (const [, cat] of categoriasExistentes) {
        const canaisDaCategoria = guild.channels.cache.filter(c => c.parentId === cat.id);
        for (const [, canal] of canaisDaCategoria) {
          await canal.delete().catch(() => {});
        }
        await cat.delete().catch(() => {});
      }

      saveFilas({});
      await interaction.editReply({ content: '⏳ Criando novas categorias e canais...' });

      let todasFilas = {};

      for (const [nomeCategoria, canais] of Object.entries(CATEGORIAS)) {
        const categoria = await guild.channels.create({
          name: nomeCategoria,
          type: ChannelType.GuildCategory
        });

        for (const nomeCanal of canais) {
          const canal = await guild.channels.create({
            name: nomeCanal,
            type: ChannelType.GuildText,
            parent: categoria.id
          });

          if (nomeCanal.includes('regras-full-soco')) {
            await canal.send({ content: REGRAS_FULL_SOCO });
          } else {
            const modeMatch = nomeCanal.match(/(\d+x\d+[-\w]*)/i);
            const modeName = modeMatch ? modeMatch[1] : nomeCanal;
            const modeFull = modeName + (nomeCategoria.includes('MOBILE') ? ' Mobile' :
              nomeCategoria.includes('EMULADOR') ? ' Emulador' :
              nomeCategoria.includes('MISTO') ? ' Misto' : ' Full Soco');

            const filasCanal = await enviarEmbedsValores(canal, modeFull);
            todasFilas = { ...todasFilas, ...filasCanal };
          }
        }
      }

      saveFilas(todasFilas);
      await interaction.editReply({ content: `✅ Setup concluído! ${Object.keys(todasFilas).length} filas criadas.` });

    } catch (err) {
      console.error(err);
      await interaction.editReply({ content: `❌ Erro: ${err.message}` });
    }
  },

  enviarEmbedsValores
};
