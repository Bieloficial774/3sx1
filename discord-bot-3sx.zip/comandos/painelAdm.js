const {
  SlashCommandBuilder, PermissionFlagsBits,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle
} = require('discord.js');

const CARGO_ADM = '1488281927784988754';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('painel-adm')
    .setDescription('Posta o painel de bate ponto dos admins neste canal')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const membro = interaction.member;
    if (!membro.roles.cache.has(CARGO_ADM) && !membro.permissions.has('Administrator')) {
      return interaction.reply({ content: '❌ Apenas administradores podem usar este comando.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setTitle('🟢 Painel de Admins | Bate Ponto')
      .setDescription(
        '**Clique em ✅ Entrar na Fila** para ficar disponível e receber notificações de partidas.\n' +
        '**Clique em 🔴 Sair da Fila** quando for descansar.\n\n' +
        '> Seu Pix será usado automaticamente quando uma partida for atribuída a você.\n\n' +
        '**Admins disponíveis agora:**\nNenhum'
      )
      .setColor('#00C851')
      .setFooter({ text: 'Free Fire Bet Bot 🔥 | Atualizado automaticamente' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('adm_entrar')
        .setLabel('✅ Entrar na Fila')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('adm_sair')
        .setLabel('🔴 Sair da Fila')
        .setStyle(ButtonStyle.Danger)
    );

    await interaction.reply({ content: '✅ Painel postado!', ephemeral: true });
    await interaction.channel.send({ embeds: [embed], components: [row] });
  }
};
