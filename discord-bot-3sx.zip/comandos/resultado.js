const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { getPartidas, savePartidas } = require('../utils/database');

const CARGO_ADM = '1488281927784988754';
const CANAL_FILA_ADM = '1488298774294958261';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('resultado')
    .setDescription('Declara o vencedor de uma partida')
    .addUserOption(opt =>
      opt.setName('vencedor')
        .setDescription('O jogador que venceu')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('sala')
        .setDescription('ID da sala (número de 5 dígitos)')
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: false });

    const membro = interaction.member;
    if (!membro.roles.cache.has(CARGO_ADM) && !membro.permissions.has('Administrator')) {
      return interaction.editReply({ content: '❌ Apenas administradores podem usar este comando.' });
    }

    const vencedor = interaction.options.getUser('vencedor');
    const salaRaw = interaction.options.getString('sala');
    if (!salaRaw) {
      return interaction.editReply({ content: '❌ Informe o ID da sala. Exemplo: `/resultado vencedor:@jogador sala:12345`' });
    }
    const salaId = salaRaw.trim();

    const partidas = getPartidas();
    const partida = partidas[salaId];

    if (!partida) {
      return interaction.editReply({ content: `❌ Sala **#${salaId}** não encontrada. Verifique o ID.` });
    }

    if (partida.status === 'encerrada') {
      return interaction.editReply({ content: `❌ A sala **#${salaId}** já foi encerrada.` });
    }

    if (!partida.jogadores.includes(vencedor.id)) {
      return interaction.editReply({
        content: `❌ <@${vencedor.id}> não está na sala **#${salaId}**.\nJogadores: ${partida.jogadores.map(j => `<@${j}>`).join(', ')}`
      });
    }

    const perdedorId = partida.jogadores.find(j => j !== vencedor.id);
    const valor = partida.valor || 10;
    const TAXA_PERCENTUAL = 0.05;
    const TAXA_FIXA = 0.25;
    const taxa = valor >= 50 ? valor * TAXA_PERCENTUAL : TAXA_FIXA;
    const premioLiquido = valor * 2;

    partida.status = 'encerrada';
    partida.vencedor = vencedor.id;
    partida.encerradoEm = new Date().toISOString();
    savePartidas(partidas);

    const embed = new EmbedBuilder()
      .setTitle('🏆 Resultado da Partida!')
      .addFields(
        { name: '🎮 Sala', value: `#${salaId}`, inline: true },
        { name: '🎯 Modo', value: partida.modo || 'N/A', inline: true },
        { name: '🏆 Vencedor', value: `<@${vencedor.id}>`, inline: false },
        { name: '😔 Perdedor', value: perdedorId ? `<@${perdedorId}>` : 'N/A', inline: false },
        { name: '💰 Valor apostado', value: `R$ ${valor.toFixed(2)}`, inline: true },
        { name: '🏅 Prêmio líquido', value: `R$ ${premioLiquido.toFixed(2)}`, inline: true },
        { name: '💸 Taxa', value: `R$ ${taxa.toFixed(2)}`, inline: true }
      )
      .setColor('#FFD700')
      .setFooter({ text: `Encerrado por ${interaction.user.username} • Free Fire Bet Bot 🔥` })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });

    const canalSala = interaction.guild.channels.cache.get(partida.canalId);
    if (canalSala) {
      await canalSala.send({
        content: `🏆 <@${vencedor.id}> venceu! Parabéns!\n💰 Prêmio: **R$ ${premioLiquido.toFixed(2)}**\n😔 <@${perdedorId}> boa sorte na próxima!`,
        embeds: [embed]
      }).catch(() => {});

      setTimeout(async () => {
        await canalSala.delete().catch(() => {});
      }, 30000);
    }

    const canalFilaAdm = interaction.guild.channels.cache.get(CANAL_FILA_ADM);
    if (canalFilaAdm) {
      await canalFilaAdm.send({
        content: `✅ Partida #${salaId} encerrada por <@${interaction.user.id}>`,
        embeds: [embed]
      });
    }

    console.log(`[RESULTADO] Sala #${salaId} | Vencedor: ${vencedor.username} | Prêmio: R$${premioLiquido}`);
  }
};
