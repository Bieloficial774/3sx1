const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getFilas, saveFilas } = require('../utils/database');
const { enviarEmbedsValores } = require('./setupFF');

const CATEGORIAS = {
  '📱 MOBILE': ['🎮・1x1-mob', '🎮・2x2-mob', '🎮・3x3-mob', '🎮・4x4-mob'],
  '🖥️ MISTO': ['🎮・2x2-misto', '🎮・3x3-misto', '🎮・4x4-misto'],
  '💻 EMULADOR': ['🎮・1x1-emu', '🎮・2x2-emu', '🎮・3x3-emu', '🎮・4x4-emu'],
  '🥊 FULL SOCO': ['📜・regras-full-soco', '🥊・1x1-full-soco', '🥊・2x2-full-soco', '🥊・3x3-full-soco', '🥊・4x4-full-soco']
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('criar-categorias')
    .setDescription('Cria as categorias e canais de apostas Free Fire')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const guild = interaction.guild;

    try {
      let criados = 0;
      let todasFilas = getFilas();

      for (const [nomeCategoria, canais] of Object.entries(CATEGORIAS)) {
        const categoriaExistente = guild.channels.cache.find(
          c => c.type === ChannelType.GuildCategory && c.name === nomeCategoria
        );

        let categoria = categoriaExistente;
        if (!categoria) {
          categoria = await guild.channels.create({
            name: nomeCategoria,
            type: ChannelType.GuildCategory
          });
          criados++;
        }

        for (const nomeCanal of canais) {
          const canalExistente = guild.channels.cache.find(
            c => c.type === ChannelType.GuildText && c.name === nomeCanal && c.parentId === categoria.id
          );

          if (!canalExistente) {
            const canal = await guild.channels.create({
              name: nomeCanal,
              type: ChannelType.GuildText,
              parent: categoria.id
            });

            if (!nomeCanal.includes('regras')) {
              const modeMatch = nomeCanal.match(/(\d+x\d+[-\w]*)/i);
              const modeName = modeMatch ? modeMatch[1] : nomeCanal;
              const modeFull = modeName + (nomeCategoria.includes('MOBILE') ? ' Mobile' :
                nomeCategoria.includes('EMULADOR') ? ' Emulador' :
                nomeCategoria.includes('MISTO') ? ' Misto' : ' Full Soco');

              const filasCanal = await enviarEmbedsValores(canal, modeFull);
              todasFilas = { ...todasFilas, ...filasCanal };
            }
            criados++;
          }
        }
      }

      saveFilas(todasFilas);
      await interaction.editReply({ content: `✅ Criados ${criados} canais/categorias com sucesso!` });
    } catch (err) {
      console.error(err);
      await interaction.editReply({ content: `❌ Erro: ${err.message}` });
    }
  }
};
