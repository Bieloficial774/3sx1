const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getAdmConfig } = require('../utils/database');

const CARGO_ADM = '1488281927784988754';
const CANAL_PIX = '1488296472385556480';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('configurar-pix')
    .setDescription('Configura sua chave Pix (apenas administradores)'),

  async execute(interaction) {
    const membro = interaction.member;

    if (!membro.roles.cache.has(CARGO_ADM) && !membro.permissions.has('Administrator')) {
      return interaction.reply({ content: '❌ Apenas administradores podem usar este comando.', ephemeral: true });
    }

    if (interaction.channelId !== CANAL_PIX) {
      return interaction.reply({
        content: `❌ Este comando só pode ser usado no canal <#${CANAL_PIX}>`,
        ephemeral: true
      });
    }

    const admConfig = getAdmConfig();
    const pixAtual = admConfig[interaction.user.id];

    const embed = new EmbedBuilder()
      .setTitle('💳 Configurar Chave Pix')
      .setDescription('Selecione o tipo de chave Pix que deseja cadastrar:')
      .setColor('#00C851')
      .setFooter({ text: `Configurando para: ${interaction.user.username}` });

    if (pixAtual) {
      embed.addFields({
        name: '✅ Chave atual cadastrada',
        value: `Tipo: **${pixAtual.tipo}**\nChave: ||${pixAtual.chave}||`
      });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`pix_tipo_cpf_${interaction.user.id}`)
        .setLabel('🪪 CPF')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`pix_tipo_aleatoria_${interaction.user.id}`)
        .setLabel('🔑 Chave Aleatória')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`pix_tipo_email_${interaction.user.id}`)
        .setLabel('📧 Email')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`pix_tipo_telefone_${interaction.user.id}`)
        .setLabel('📱 Número')
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  }
};
