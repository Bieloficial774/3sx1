const { EmbedBuilder } = require('discord.js');

const CARGO_ADM = '1488281927784988754';

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (message.author.bot) return;

    if (message.content.startsWith('.id')) {
      const membro = message.member;

      if (!membro.roles.cache.has(CARGO_ADM) && !membro.permissions.has('Administrator')) {
        return;
      }

      const args = message.content.slice(4).trim().split(/\s+/);

      if (args.length < 2) {
        const aviso = await message.channel.send('❌ Use: `.id [ID_SALA] [SENHA]`');
        setTimeout(() => aviso.delete().catch(() => {}), 5000);
        await message.delete().catch(() => {});
        return;
      }

      const [idSala, senha] = args;

      if (isNaN(idSala) || isNaN(senha)) {
        const aviso = await message.channel.send('❌ ID e senha devem ser números.');
        setTimeout(() => aviso.delete().catch(() => {}), 5000);
        await message.delete().catch(() => {});
        return;
      }

      await message.delete().catch(() => {});

      const embed = new EmbedBuilder()
        .setTitle('🎮 Sala Criada')
        .addFields(
          { name: '🆔 ID', value: idSala.toString(), inline: true },
          { name: '🔑 Senha', value: senha.toString(), inline: true }
        )
        .setColor('#FF6600')
        .setTimestamp();

      await message.channel.send({ embeds: [embed] });
      console.log(`[.id] Admin ${message.author.username} criou sala ID:${idSala} Senha:${senha}`);
    }
  }
};
