const {
  ModalBuilder, TextInputBuilder, TextInputStyle,
  ActionRowBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle,
  ChannelType, PermissionsBitField, AttachmentBuilder
} = require('discord.js');
const {
  getAdmConfig, saveAdmConfig,
  getPartidas, savePartidas,
  getFilas, saveFilas,
  getAdmOnline, saveAdmOnline
} = require('../utils/database');
const { gerarQRCodePix } = require('../utils/pixQRCode');
const { buildEmbedValor, getLogo } = require('../comandos/setupFF');
const fs = require('fs');

const CARGO_ADM = '1488281927784988754';
const CANAL_FILA_ADM = '1488298774294958261';
const CANAL_PIX = '1488296472385556480';
const TAXA_PERCENTUAL = 0.05;
const TAXA_FIXA = 0.25;
const VALOR_MINIMO_TAXA_PERCENTUAL = 50;

const salasAtivas = new Map();
const salasAguardandoAdm = new Map();

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {

    if (interaction.isChatInputCommand()) {
      const comando = client.commands.get(interaction.commandName);
      if (!comando) return;
      try {
        await comando.execute(interaction);
      } catch (err) {
        console.error(`Erro no comando ${interaction.commandName}:`, err);
        const msg = { content: '❌ Ocorreu um erro ao executar o comando.', ephemeral: true };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(msg).catch(() => {});
        } else {
          await interaction.reply(msg).catch(() => {});
        }
      }
      return;
    }

    if (interaction.isButton()) {
      const customId = interaction.customId;

      if (customId.startsWith('fila_gelon_') || customId.startsWith('fila_geloi_')) {
        const modoGelo = customId.startsWith('fila_gelon_') ? 'geloNormal' : 'geloInfinito';
        const modoLabel = modoGelo === 'geloNormal' ? 'Gelo Normal' : 'Gelo Infinito';
        const msgId = customId.startsWith('fila_gelon_')
          ? customId.replace('fila_gelon_', '')
          : customId.replace('fila_geloi_', '');

        await handleEntrarFilaValor(interaction, client, msgId, modoGelo, modoLabel);
        return;
      }

      if (customId.startsWith('sair_msg_')) {
        const msgId = customId.replace('sair_msg_', '');
        await handleSairFila(interaction, msgId);
        return;
      }

      if (customId === 'adm_entrar' || customId === 'adm_sair') {
        await handleAdmFila(interaction, customId === 'adm_entrar');
        return;
      }

      if (customId.startsWith('adm_aceitar_')) {
        await handleAdmAceitar(interaction, client, customId.replace('adm_aceitar_', ''));
        return;
      }

      if (customId.startsWith('pix_tipo_')) {
        const partes = customId.split('_');
        const tipo = partes[2];
        const admId = partes[3];

        if (interaction.user.id !== admId) {
          return interaction.reply({ content: '❌ Esse botão não é para você.', ephemeral: true });
        }
        if (interaction.channelId !== CANAL_PIX) {
          return interaction.reply({ content: `❌ Use este comando apenas no canal <#${CANAL_PIX}>`, ephemeral: true });
        }

        const tipoLabels = {
          cpf: 'CPF (apenas números)',
          aleatoria: 'Chave Aleatória (código UUID)',
          email: 'Email',
          telefone: 'Telefone (+55...)'
        };

        const modal = new ModalBuilder()
          .setCustomId(`pix_modal_${tipo}_${admId}`)
          .setTitle('💳 Inserir Chave Pix');

        const input = new TextInputBuilder()
          .setCustomId('chave_pix')
          .setLabel(tipoLabels[tipo] || 'Chave Pix')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMinLength(5)
          .setMaxLength(80);

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await interaction.showModal(modal);
        return;
      }

      if (customId.startsWith('confirmar_')) {
        await handleConfirmar(interaction, client);
        return;
      }

      if (customId.startsWith('cancelar_')) {
        await interaction.deferReply({ ephemeral: true });
        const salaId = customId.replace('cancelar_', '');

        const partidas = getPartidas();
        for (const [id, partida] of Object.entries(partidas)) {
          if (partida.canalId === salaId) {
            for (const jogador of partida.jogadores) {
              salasAtivas.delete(jogador);
            }
            delete partidas[id];
          }
        }
        savePartidas(partidas);
        await interaction.editReply({ content: '❌ Sala cancelada.' });
        const canal = interaction.guild.channels.cache.get(salaId);
        if (canal) await canal.delete().catch(() => {});
        return;
      }

      if (customId.startsWith('ver_meu_pix_')) {
        const admId = customId.replace('ver_meu_pix_', '');
        if (interaction.user.id !== admId) {
          return interaction.reply({ content: '❌ Apenas você pode ver sua chave.', ephemeral: true });
        }
        const admConfig = getAdmConfig();
        const cfg = admConfig[admId];
        if (!cfg) {
          return interaction.reply({ content: '❌ Você ainda não configurou sua chave Pix.', ephemeral: true });
        }
        const embed = new EmbedBuilder()
          .setTitle('🔑 Sua Chave Pix')
          .addFields(
            { name: 'Tipo', value: cfg.tipo, inline: true },
            { name: 'Chave', value: cfg.chave, inline: true }
          )
          .setColor('#00C851');
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }
    }

    if (interaction.isModalSubmit()) {
      if (interaction.customId.startsWith('pix_modal_')) {
        const partes = interaction.customId.split('_');
        const tipo = partes[2];
        const admId = partes[3];

        if (interaction.user.id !== admId) {
          return interaction.reply({ content: '❌ Este formulário não é para você.', ephemeral: true });
        }

        const chavePix = interaction.fields.getTextInputValue('chave_pix').trim();
        const tipoLabels = { cpf: 'CPF', aleatoria: 'Chave Aleatória', email: 'Email', telefone: 'Telefone' };

        const admConfig = getAdmConfig();
        admConfig[admId] = {
          tipo: tipoLabels[tipo] || tipo,
          chave: chavePix,
          discord: interaction.user.username
        };
        saveAdmConfig(admConfig);

        const embed = new EmbedBuilder()
          .setTitle('✅ Chave Pix Configurada!')
          .setDescription('Sua chave Pix foi salva com sucesso.')
          .addFields(
            { name: 'Tipo', value: tipoLabels[tipo] || tipo, inline: true },
            { name: 'Chave', value: `||${chavePix}||`, inline: true }
          )
          .setColor('#00C851')
          .setFooter({ text: 'Apenas você pode ver esta mensagem' });

        await interaction.reply({ embeds: [embed], ephemeral: true });
        console.log(`[PIX] Admin ${interaction.user.username} configurou chave ${tipoLabels[tipo]}`);
        return;
      }
    }
  }
};

function buildEmbed(fila) {
  return buildEmbedValor(fila.modo, fila.valor, fila.geloNormal, fila.geloInfinito);
}

function buildRow(msgId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`fila_gelon_${msgId}`)
      .setLabel('🎮 Gelo Normal')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`fila_geloi_${msgId}`)
      .setLabel('🎮 Gelo Infinito')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`sair_msg_${msgId}`)
      .setLabel('❌ Sair da fila')
      .setStyle(ButtonStyle.Danger)
  );
}

async function handleSairFila(interaction, msgId) {
  await interaction.deferReply({ ephemeral: true });

  const filas = getFilas();
  const fila = filas[msgId];

  if (!fila) {
    return interaction.editReply({ content: '❌ Fila não encontrada.' });
  }

  let saiu = false;
  if (fila.geloNormal === interaction.user.id) {
    fila.geloNormal = null;
    saiu = true;
  }
  if (fila.geloInfinito === interaction.user.id) {
    fila.geloInfinito = null;
    saiu = true;
  }

  if (!saiu) {
    return interaction.editReply({ content: '❌ Você não está nesta fila.' });
  }

  saveFilas(filas);

  try {
    const canal = interaction.guild.channels.cache.get(fila.canalId);
    if (canal) {
      const msg = await canal.messages.fetch(msgId);
      await msg.edit({ embeds: [buildEmbed(fila)], files: [getLogo()], components: [buildRow(msgId)] });
    }
  } catch {}

  await interaction.editReply({ content: '✅ Você saiu da fila.' });
}

async function handleEntrarFilaValor(interaction, client, msgId, modoGelo, modoLabel) {
  await interaction.deferReply({ ephemeral: true });

  try {
    const filas = getFilas();
    const fila = filas[msgId];

    if (!fila) {
      return interaction.editReply({ content: '❌ Esta fila não foi encontrada. Use /setup-ff para recriar.' });
    }

    const userId = interaction.user.id;

    if (fila.geloNormal === userId || fila.geloInfinito === userId) {
      return interaction.editReply({ content: '❌ Você já está nesta fila! Clique em "Sair da fila" primeiro.' });
    }

    const jaEmFila = Object.values(filas).some(
      f => f.geloNormal === userId || f.geloInfinito === userId
    );
    if (jaEmFila) {
      return interaction.editReply({ content: '❌ Você já está em uma fila ativa! Saia dela primeiro.' });
    }

    const oponenteId = fila[modoGelo];

    if (oponenteId && oponenteId !== userId) {
      fila[modoGelo] = null;
      saveFilas(filas);

      try {
        const canal = interaction.guild.channels.cache.get(fila.canalId);
        if (canal) {
          const msg = await canal.messages.fetch(msgId);
          await msg.edit({ embeds: [buildEmbed(fila)], files: [getLogo()], components: [buildRow(msgId)] });
        }
      } catch {}

      await criarSalaPartida(interaction, client, fila, userId, oponenteId, modoLabel);
    } else {
      fila[modoGelo] = userId;
      saveFilas(filas);

      try {
        const canal = interaction.guild.channels.cache.get(fila.canalId);
        if (canal) {
          const msg = await canal.messages.fetch(msgId);
          await msg.edit({ embeds: [buildEmbed(fila)], files: [getLogo()], components: [buildRow(msgId)] });
        }
      } catch {}

      await interaction.editReply({
        content: `✅ Você entrou na fila de **${modoLabel}** por **R$ ${fila.valor.toFixed(2)}**!\nAguardando oponente...`
      });

      console.log(`[FILA] ${interaction.user.username} entrou na fila ${modoLabel} R$${fila.valor} (msg: ${msgId})`);

      const canalFilaAdm = interaction.guild.channels.cache.get(CANAL_FILA_ADM);
      if (canalFilaAdm) {
        const embedAdm = new EmbedBuilder()
          .setTitle('🔔 Alguém entrou na fila!')
          .addFields(
            { name: 'Jogador', value: `<@${userId}>`, inline: true },
            { name: 'Modo', value: `${fila.modo} - ${modoLabel}`, inline: true },
            { name: 'Valor', value: `R$ ${fila.valor.toFixed(2)}`, inline: true }
          )
          .setColor('#FF6600')
          .setTimestamp();

        await canalFilaAdm.send({ content: `<@&${CARGO_ADM}>`, embeds: [embedAdm] });
      }
    }
  } catch (err) {
    console.error('[ENTRAR FILA VALOR]', err);
    await interaction.editReply({ content: `❌ Erro: ${err.message}` });
  }
}

async function handleAdmFila(interaction, entrando) {
  const membro = interaction.member;
  if (!membro.roles.cache.has(CARGO_ADM) && !membro.permissions.has('Administrator')) {
    return interaction.reply({ content: '❌ Apenas administradores podem usar isso.', ephemeral: true });
  }

  const admConfig = getAdmConfig();
  if (!admConfig[interaction.user.id]) {
    return interaction.reply({
      content: '❌ Você ainda não tem uma chave Pix cadastrada. Use `/configurar-pix` primeiro.',
      ephemeral: true
    });
  }

  const admOnline = getAdmOnline();
  admOnline[interaction.user.id] = entrando;
  saveAdmOnline(admOnline);

  const onlineIds = Object.entries(admOnline).filter(([, v]) => v).map(([id]) => id);
  const listaOnline = onlineIds.length > 0
    ? onlineIds.map(id => `✅ <@${id}>`).join('\n')
    : 'Nenhum';

  const embed = new EmbedBuilder()
    .setTitle('🟢 Painel de Admins | Bate Ponto')
    .setDescription(
      '**Clique em ✅ Entrar na Fila** para ficar disponível e receber notificações de partidas.\n' +
      '**Clique em 🔴 Sair da Fila** quando for descansar.\n\n' +
      '> Seu Pix será usado automaticamente quando uma partida for atribuída a você.\n\n' +
      `**Admins disponíveis agora:**\n${listaOnline}`
    )
    .setColor(onlineIds.length > 0 ? '#00C851' : '#FF4444')
    .setFooter({ text: 'Free Fire Bet Bot 🔥 | Atualizado automaticamente' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('adm_entrar').setLabel('✅ Entrar na Fila').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('adm_sair').setLabel('🔴 Sair da Fila').setStyle(ButtonStyle.Danger)
  );

  await interaction.update({ embeds: [embed], components: [row] });

  const statusMsg = entrando
    ? `✅ Você entrou na fila de admins! Será notificado quando houver partidas.`
    : `🔴 Você saiu da fila de admins.`;

  await interaction.followUp({ content: statusMsg, ephemeral: true });
  console.log(`[ADM FILA] ${interaction.user.username} ${entrando ? 'entrou' : 'saiu'} da fila de admins`);
}

async function criarSalaPartida(interaction, client, fila, jogador1, jogador2, modoLabel) {
  const guild = interaction.guild;
  const idSala = Math.floor(10000 + Math.random() * 90000).toString();
  const valor = fila.valor;
  const taxa = valor >= VALOR_MINIMO_TAXA_PERCENTUAL ? valor * TAXA_PERCENTUAL : TAXA_FIXA;
  const premioLiquido = valor * 2;
  const valorComTaxa = valor + taxa;

  let categoriaSalas = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && c.name === '🎮・SALAS ATIVAS'
  );
  if (!categoriaSalas) {
    categoriaSalas = await guild.channels.create({
      name: '🎮・SALAS ATIVAS',
      type: ChannelType.GuildCategory
    });
  }

  const canalSala = await guild.channels.create({
    name: `sala-${idSala}`,
    type: ChannelType.GuildText,
    parent: categoriaSalas.id,
    permissionOverwrites: [
      { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
      { id: jogador1, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
      { id: jogador2, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
    ]
  });

  const partidas = getPartidas();
  partidas[idSala] = {
    id: idSala,
    canalId: canalSala.id,
    modo: `${fila.modo} - ${modoLabel}`,
    valor,
    jogadores: [jogador1, jogador2],
    status: 'aguardando_pagamento'
  };
  savePartidas(partidas);

  const embedSala = new EmbedBuilder()
    .setTitle('⚔️ Partida Encontrada!')
    .addFields(
      { name: '🎮 Modo', value: `${fila.modo} - ${modoLabel}`, inline: true },
      { name: '🏷️ Sala', value: `#${idSala}`, inline: true },
      { name: '💰 Valor da aposta', value: `R$ ${valor.toFixed(2)}`, inline: true },
      { name: '💸 Taxa', value: `R$ ${taxa.toFixed(2)}`, inline: true },
      { name: '💳 Total a pagar (cada)', value: `R$ ${valorComTaxa.toFixed(2)}`, inline: true },
      { name: '🏆 Prêmio líquido', value: `R$ ${premioLiquido.toFixed(2)}`, inline: true },
      { name: '👥 Jogadores', value: `<@${jogador1}> vs <@${jogador2}>` },
      { name: '⏳ Status', value: 'Aguardando admin aceitar e enviar Pix...' }
    )
    .setColor('#FFA500')
    .setFooter({ text: 'Free Fire Bet Bot 🔥' });

  await canalSala.send({
    content: `<@${jogador1}> <@${jogador2}> ⚔️ Partida encontrada! Aguarde o Pix ser enviado pelo admin.`,
    embeds: [embedSala]
  });

  salasAguardandoAdm.set(idSala, {
    canalSalaId: canalSala.id,
    jogador1,
    jogador2,
    valor,
    valorComTaxa,
    premioLiquido,
    modo: `${fila.modo} - ${modoLabel}`
  });

  await interaction.editReply({ content: `⚔️ Oponente encontrado! Acesse <#${canalSala.id}>` });
  console.log(`[SALA] Sala #${idSala} criada: ${jogador1} vs ${jogador2} | ${fila.modo} | R$${valor}`);

  const admConfig = getAdmConfig();
  const admOnline = getAdmOnline();
  const admOnlineIds = Object.entries(admOnline).filter(([, v]) => v).map(([id]) => id);
  const admOnlineComPix = admOnlineIds.filter(id => admConfig[id]);
  const pingOnline = admOnlineComPix.length > 0
    ? admOnlineComPix.map(id => `<@${id}>`).join(' ')
    : `<@&${CARGO_ADM}>`;

  const canalFilaAdm = guild.channels.cache.get(CANAL_FILA_ADM);
  if (canalFilaAdm) {
    const embedAdm = new EmbedBuilder()
      .setTitle('⚔️ Nova Partida! Aceite para enviar o Pix')
      .addFields(
        { name: '🏷️ Sala', value: `#${idSala} — <#${canalSala.id}>`, inline: true },
        { name: '🎮 Modo', value: `${fila.modo} - ${modoLabel}`, inline: true },
        { name: '💳 Valor a receber (cada)', value: `R$ ${valorComTaxa.toFixed(2)}`, inline: true },
        { name: '👥 Jogadores', value: `<@${jogador1}> vs <@${jogador2}>` }
      )
      .setColor('#FFD700')
      .setTimestamp();

    const rowAdm = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`adm_aceitar_${idSala}`)
        .setLabel('✅ Aceitar e enviar Pix')
        .setStyle(ButtonStyle.Success)
    );

    await canalFilaAdm.send({
      content: `${pingOnline} 🔔 Nova partida aberta! Primeiro a aceitar envia o Pix.`,
      embeds: [embedAdm],
      components: [rowAdm]
    });
  }
}

async function handleAdmAceitar(interaction, client, idSala) {
  await interaction.deferReply({ ephemeral: true });

  const membro = interaction.member;
  if (!membro.roles.cache.has(CARGO_ADM) && !membro.permissions.has('Administrator')) {
    return interaction.editReply({ content: '❌ Apenas administradores podem aceitar partidas.' });
  }

  const admConfig = getAdmConfig();
  const pixInfo = admConfig[interaction.user.id];
  if (!pixInfo) {
    return interaction.editReply({ content: '❌ Você não tem Pix cadastrado. Use `/configurar-pix` primeiro.' });
  }

  const sala = salasAguardandoAdm.get(idSala);
  if (!sala) {
    const desabilitado = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`adm_aceitar_${idSala}`)
        .setLabel('✅ Já aceito por outro admin')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true)
    );
    await interaction.message.edit({ components: [desabilitado] }).catch(() => {});
    return interaction.editReply({ content: '⚠️ Esta partida já foi aceita por outro admin.' });
  }

  salasAguardandoAdm.delete(idSala);

  const { canalSalaId, jogador1, jogador2, valorComTaxa, premioLiquido, modo } = sala;

  const desabilitado = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`adm_aceitar_${idSala}`)
      .setLabel(`✅ Aceito por ${interaction.user.username}`)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(true)
  );
  await interaction.message.edit({ components: [desabilitado] }).catch(() => {});

  try {
    const { filePath, payload } = await gerarQRCodePix(pixInfo.chave, valorComTaxa, 'ORG 3SX');
    const attachment = new AttachmentBuilder(filePath, { name: 'qrcode_pix.png' });

    const embedPix = new EmbedBuilder()
      .setTitle('💳 Pagamento via Pix')
      .addFields(
        { name: '🎮 Modo', value: modo, inline: true },
        { name: '💰 Valor a pagar', value: `R$ ${valorComTaxa.toFixed(2)}`, inline: true },
        { name: '🏆 Prêmio líquido', value: `R$ ${premioLiquido.toFixed(2)}`, inline: true },
        { name: '📋 Tipo da chave', value: pixInfo.tipo, inline: true },
        { name: '🔑 Chave Pix', value: `\`${pixInfo.chave}\``, inline: false },
        { name: '📟 Copia e Cola', value: `\`\`\`${payload}\`\`\`` }
      )
      .setImage('attachment://qrcode_pix.png')
      .setColor('#00C851')
      .setFooter({ text: `Admin: ${interaction.user.username} • Free Fire Bet Bot 🔥` });

    const canalSala = interaction.guild.channels.cache.get(canalSalaId);
    if (canalSala) {
      const rowCancelar = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`cancelar_${canalSalaId}`)
          .setLabel('❌ Cancelar sala')
          .setStyle(ButtonStyle.Danger)
      );
      await canalSala.send({
        content: `<@${jogador1}> <@${jogador2}> 💳 **Pague agora para confirmar sua aposta!**`,
        embeds: [embedPix],
        files: [attachment],
        components: [rowCancelar]
      });
    }

    setTimeout(() => { try { fs.unlinkSync(filePath); } catch {} }, 15000);

    await interaction.editReply({ content: `✅ Pix enviado para a sala #${idSala}! Chave: \`${pixInfo.chave}\`` });
    console.log(`[PIX ACEITO] Admin ${interaction.user.username} aceitou sala #${idSala}`);
  } catch (err) {
    console.error('[ADM ACEITAR QR]', err);
    await interaction.editReply({ content: `❌ Erro ao gerar QR code: ${err.message}` });
  }
}

async function handleConfirmar(interaction, client) {
  await interaction.deferReply({ ephemeral: true });
  await interaction.editReply({ content: '✅ Partida em andamento!' });
}
