const QRCode = require('qrcode');
const path = require('path');
const fs = require('fs');

async function gerarQRCodePix(chavePix, valor, nome) {
  const tmpDir = path.join(__dirname, '../tmp');
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

  const chaveNormalizada = normalizarChave(chavePix);
  const pixPayload = gerarPayloadPix(chaveNormalizada, valor, nome);
  const filePath = path.join(tmpDir, `pix_${Date.now()}.png`);

  await QRCode.toFile(filePath, pixPayload, {
    errorCorrectionLevel: 'M',
    color: { dark: '#000000', light: '#ffffff' },
    width: 400,
    margin: 2
  });

  return { filePath, payload: pixPayload };
}

function normalizarChave(chave) {
  chave = chave.trim();
  const soDigitos = chave.replace(/\D/g, '');

  if (/^\+55\d{10,11}$/.test(chave)) return chave;
  if (/^55\d{10,11}$/.test(soDigitos)) return `+${soDigitos}`;
  if (/^\d{10,11}$/.test(soDigitos)) return `+55${soDigitos}`;

  if (/^\d{11}$/.test(soDigitos) && soDigitos[0] !== '5') return chave;

  return chave;
}

function campo(id, value) {
  const len = value.length.toString().padStart(2, '0');
  return `${id}${len}${value}`;
}

function gerarPayloadPix(chave, valor, nome) {
  nome = (nome || 'APOSTAS FF')
    .substring(0, 25)
    .toUpperCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Z0-9 ]/g, '')
    .trim() || 'APOSTAS FF';

  const valorStr = Number(valor).toFixed(2);
  const cidade = 'SAO PAULO';

  const merchantInfo =
    campo('00', 'BR.GOV.BCB.PIX') +
    campo('01', chave);

  const payload =
    campo('00', '01') +
    campo('26', merchantInfo) +
    campo('52', '0000') +
    campo('53', '986') +
    campo('54', valorStr) +
    campo('58', 'BR') +
    campo('59', nome) +
    campo('60', cidade) +
    campo('62', campo('05', '***')) +
    '6304';

  const crc = calcularCRC16(payload);
  return payload + crc;
}

function calcularCRC16(str) {
  let crc = 0xFFFF;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = (crc & 0x8000) ? (crc << 1) ^ 0x1021 : crc << 1;
    }
  }
  return (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
}

module.exports = { gerarQRCodePix };
