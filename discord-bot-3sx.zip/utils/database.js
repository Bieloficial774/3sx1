const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../database');

function readDB(file) {
  try {
    const data = fs.readFileSync(path.join(DB_PATH, file), 'utf8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}

function writeDB(file, data) {
  fs.writeFileSync(path.join(DB_PATH, file), JSON.stringify(data, null, 2));
}

function getUsuarios() { return readDB('usuarios.json'); }
function saveUsuarios(data) { writeDB('usuarios.json', data); }

function getPartidas() { return readDB('partidas.json'); }
function savePartidas(data) { writeDB('partidas.json', data); }

function getAdmConfig() { return readDB('admConfig.json'); }
function saveAdmConfig(data) { writeDB('admConfig.json', data); }

function getFilas() { return readDB('filas.json'); }
function saveFilas(data) { writeDB('filas.json', data); }

function getAdmOnline() { return readDB('admOnline.json'); }
function saveAdmOnline(data) { writeDB('admOnline.json', data); }

function getOuCriarUsuario(userId) {
  const usuarios = getUsuarios();
  if (!usuarios[userId]) {
    usuarios[userId] = { saldo: 100, nome: userId };
    saveUsuarios(usuarios);
  }
  return usuarios[userId];
}

module.exports = {
  getUsuarios, saveUsuarios,
  getPartidas, savePartidas,
  getAdmConfig, saveAdmConfig,
  getFilas, saveFilas,
  getAdmOnline, saveAdmOnline,
  getOuCriarUsuario
};
