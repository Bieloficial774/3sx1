require('dotenv').config();
const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

const TOKEN = process.env.DISCORD_TOKEN || 'MTQ4ODAzMzU5NjQyOTA0NTgxMA.GdVKSa.KfUC0KFTTIvh8uawdB6n4Gk9wkaVjmM-7HbYPg';
const CLIENT_ID = '1488033596429045810';
const GUILD_ID = '1488033472537821234';

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

client.commands = new Collection();

const comandosDir = path.join(__dirname, 'comandos');
const arquivosComandos = fs.readdirSync(comandosDir).filter(f => f.endsWith('.js'));

const commandsData = [];
for (const arquivo of arquivosComandos) {
  const comando = require(path.join(comandosDir, arquivo));
  if (comando.data && comando.execute) {
    client.commands.set(comando.data.name, comando);
    commandsData.push(comando.data.toJSON());
    console.log(`[CMD] Carregado: /${comando.data.name}`);
  }
}

async function registrarComandos() {
  const rest = new REST({ version: '10' }).setToken(TOKEN);
  try {
    console.log('[CMD] Registrando slash commands...');
    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commandsData });
    console.log(`[CMD] ${commandsData.length} comandos registrados com sucesso!`);
  } catch (err) {
    console.error('[CMD] Erro ao registrar comandos:', err);
  }
}

const eventsDir = path.join(__dirname, 'events');
const arquivosEventos = fs.readdirSync(eventsDir).filter(f => f.endsWith('.js'));

for (const arquivo of arquivosEventos) {
  const evento = require(path.join(eventsDir, arquivo));
  if (evento.once) {
    client.once(evento.name, (...args) => evento.execute(...args, client));
  } else {
    client.on(evento.name, (...args) => evento.execute(...args, client));
  }
  console.log(`[EVT] Carregado: ${evento.name}`);
}

client.once('ready', async () => {
  console.log(`\n✅ Bot online: ${client.user.tag}`);
  console.log(`🆔 Client ID: ${CLIENT_ID}`);
  console.log(`🏠 Guild ID: ${GUILD_ID}`);
  await registrarComandos();
  console.log('🔥 Free Fire Bet Bot está pronto!\n');
});

client.login(TOKEN).catch(err => {
  console.error('❌ Erro ao fazer login:', err.message);
  process.exit(1);
});
